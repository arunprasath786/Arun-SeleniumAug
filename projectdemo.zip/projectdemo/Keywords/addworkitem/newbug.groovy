package addworkitem

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import org.openqa.selenium.Keys as Keys

import internal.GlobalVariable

public class newbug {

	private TestObject pplogoclick = findTestObject('Object Repository/Add Workitem page/pp - logo-click')
	private TestObject plusaddworkitem = findTestObject('Object Repository/proj-reg-sprint1/plus symbol -add workitem')
	private TestObject addworkitem1click = findTestObject('Object Repository/proj-reg-sprint1/Add workitem click')
	private TestObject choosetype = findTestObject('Object Repository/Add Workitem page/choose workitem type')
	private TestObject choosesubtype = findTestObject('Object Repository/Add Workitem page/choose subtype')
	private TestObject choosestatus = findTestObject('Object Repository/Add Workitem page/choose status')
	private TestObject workitemtitle = findTestObject('Object Repository/Add Workitem page/workitem- title')
	private TestObject workitembug = findTestObject('Object Repository/Add Workitem page/workitem - bug')
	private TestObject workitemsubfunct = findTestObject('Object Repository/Add Workitem page/subtype - functional')
	private TestObject workitemstatusnew = findTestObject('Object Repository/Add Workitem page/status - new')
	private TestObject bugdescrip = findTestObject('Object Repository/Add Workitem page/new bug - description')
	private TestObject bugduedate = findTestObject('Object Repository/Add Workitem page/Due date')
	private TestObject newbugsave = findTestObject('Add Workitem page/new workitem save button')
	private TestObject subtypesearch = findTestObject('Object Repository/Add Workitem page/subtype search textbox')
	private TestObject dropworktype = findTestObject('Object Repository/Add Workitem page/dropdown/workiten - type')
	private TestObject dropworksubtype = findTestObject('Object Repository/Add Workitem page/dropdown/workitem - subtype')
	private TestObject chooseassignto = findTestObject('Object Repository/Add Workitem page/choose assign to')
	private TestObject dropassignto = findTestObject('Object Repository/Add Workitem page/dropdown/workitem - assign to')
	private TestObject demoprojclick = findTestObject('Object Repository/projects page/demo project click')
	private TestObject projpageclick = findTestObject('Object Repository/projects page/project - page - click')
	private TestObject Sprintclick = findTestObject('Object Repository/Add Workitem page/Sprint click')
	private TestObject navreleasepage = findTestObject('Object Repository/projects page/Add release/nav release page')
	private TestObject demoreleaseclick = findTestObject('Object Repository/projects page/Add release/demo release click')
	
	@Keyword
	def newbugsubmit(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		addworkitemplussymb()
		WebUI.click(choosetype)
		WebUI.click(workitembug)
		WebUI.click(choosesubtype)
		WebUI.setText(subtypesearch,"functional")
		WebUI.sendKeys(subtypesearch, Keys.chord(Keys.ENTER))
		WebUI.click(choosestatus)
		WebUI.setText(subtypesearch,"new")
		WebUI.sendKeys(subtypesearch, Keys.chord(Keys.ENTER))
		WebUI.clearText(bugduedate)
		WebUI.setText(bugduedate,"01/30/2020")
		WebUI.click(bugdescrip)
		WebUI.setText(workitemtitle,"Demo bug submit")
		WebUI.setText(bugdescrip,"Demo bug description")
		WebUI.click(newbugsave)
		WebUI.click(pplogoclick)
	}

	@Keyword
	def addworkitemplussymb(){
		WebUI.click(plusaddworkitem)
		WebUI.click(addworkitem1click)
	}

	@Keyword
	def newtasksubmit(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		addworkitemplussymb()
		WebUI.click(choosetype)
		WebUI.scrollToElement(dropworktype, 30)
		WebUI.click(dropworktype)
		WebUI.click(chooseassignto)
		WebUI.scrollToElement(dropassignto, 30)
		WebUI.click(dropassignto)
		WebUI.click(choosesubtype)
		WebUI.scrollToElement(dropworksubtype, 30)
		WebUI.click(dropworksubtype)
		WebUI.clearText(bugduedate)
		WebUI.setText(bugduedate,"01/30/2020")
		WebUI.click(bugdescrip)
		WebUI.setText(workitemtitle,"test bug submit")
		WebUI.setText(bugdescrip,"test bug description")
		WebUI.click(choosestatus)
		WebUI.setText(subtypesearch,"new")
		WebUI.sendKeys(subtypesearch, Keys.chord(Keys.ENTER))
		WebUI.click(newbugsave)
	}
	
	@Keyword
	def Sprint_newtasksubmit(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprintclick)
		addworkitemplussymb()
		WebUI.click(choosetype)
		WebUI.scrollToElement(dropworktype, 30)
		WebUI.click(dropworktype)
		WebUI.click(chooseassignto)
		WebUI.scrollToElement(dropassignto, 30)
		WebUI.click(dropassignto)
		WebUI.click(choosesubtype)
		WebUI.scrollToElement(dropworksubtype, 30)
		WebUI.click(dropworksubtype)
		WebUI.clearText(bugduedate)
		WebUI.setText(bugduedate,"01/30/2020")
		WebUI.click(bugdescrip)
		WebUI.setText(workitemtitle,"test bug submit")
		WebUI.setText(bugdescrip,"test bug description")
		WebUI.click(choosestatus)
		WebUI.setText(subtypesearch,"new")
		WebUI.sendKeys(subtypesearch, Keys.chord(Keys.ENTER))
		WebUI.click(newbugsave)
		WebUI.click(pplogoclick)
	}
	
	@Keyword
	def Sprint_newBugsubmit(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprintclick)
		addworkitemplussymb()
		WebUI.click(choosetype)
		WebUI.click(workitembug)
		WebUI.click(choosesubtype)
		WebUI.setText(subtypesearch,"functional")
		WebUI.sendKeys(subtypesearch, Keys.chord(Keys.ENTER))
		WebUI.click(choosestatus)
		WebUI.setText(subtypesearch,"new")
		WebUI.sendKeys(subtypesearch, Keys.chord(Keys.ENTER))
		WebUI.clearText(bugduedate)
		WebUI.setText(bugduedate,"01/30/2020")
		WebUI.click(bugdescrip)
		WebUI.setText(workitemtitle,"Demo bug submit")
		WebUI.setText(bugdescrip,"Demo bug description")
		WebUI.click(newbugsave)
		WebUI.click(pplogoclick)
}
}