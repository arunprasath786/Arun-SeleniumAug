package projectspage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import org.openqa.selenium.Keys as Keys
import internal.GlobalVariable

public class Editprojrelspr {

	private TestObject projactionicon = findTestObject('Object Repository/projects page/Edit project/proj action icon')
	private TestObject projactionedit = findTestObject('Object Repository/projects page/Edit project/proj action - edit')
	private TestObject projactiondelete = findTestObject('Object Repository/projects page/Edit project/proj action - delete')
	private TestObject moreoptions = findTestObject('Object Repository/projects page/Edit project/release edit - more options')
	private TestObject moreoptionsedit = findTestObject('Object Repository/projects page/Edit project/release edit - more options - edit')
	private TestObject moreoptionsdelete = findTestObject('Object Repository/projects page/Edit project/release edit - more options - delete')
	private TestObject projpageclick = findTestObject('Object Repository/projects page/project - page - click')
	private TestObject chooseprojdrop = findTestObject('Object Repository/projects page/choose project drop')
	private TestObject droptextbox = findTestObject('Object Repository/projects page/subtype search textbox')
	private TestObject searchbuttonclick = findTestObject('Object Repository/projects page/search button click')
	private TestObject enddate = findTestObject('Object Repository/projects page/Add project/proj end date')
	private TestObject editsavebutton = findTestObject('Object Repository/projects page/Edit project/edit save button')
	private TestObject enterprojname = findTestObject('Object Repository/projects page/Add project/enter proj name')
	private TestObject clickenddate = findTestObject('Object Repository/projects page/Edit project/end date click')
	private TestObject dateedit = findTestObject('Object Repository/projects page/Edit project/date edit')
	private TestObject projdeletconfir = findTestObject('Object Repository/projects page/Edit project/proj delete confirm button')
	private TestObject projdeletok = findTestObject('Object Repository/projects page/Edit project/projdeletok')
	//sprint Edit
	private TestObject demoprojclick = findTestObject('Object Repository/projects page/demo project click')
	private TestObject navreleasepage = findTestObject('Object Repository/projects page/Add release/nav release page')
	private TestObject demoreleaseclick = findTestObject('Object Repository/projects page/Add release/demo release click')
	private TestObject Sprint_options = findTestObject('Object Repository/projects page/Add sprint/Sprint Edit/Sprint- Edit options')
	private TestObject Sprint_Edit = findTestObject('Object Repository/projects page/Add sprint/Sprint Edit/Sprint Edit')
	private TestObject StatusClick = findTestObject('Object Repository/projects page/Add sprint/Sprint Edit/sprint status edit')
	private TestObject StatusChange = findTestObject('Object Repository/projects page/Add sprint/Sprint Edit/status - Inprogress')
	private TestObject SprintEdit_Save = findTestObject('Object Repository/projects page/Add sprint/Sprint Edit/Edit - Save')
	private TestObject Sprint_Delete = findTestObject('Object Repository/projects page/Add sprint/Sprint Edit/Sprint Delete')
	private TestObject Sprint_View = findTestObject('Object Repository/projects page/Add sprint/Sprint Edit/Sprint View')
	private TestObject Sprint_TestExecution = findTestObject('Object Repository/projects page/Add sprint/Sprint Edit/Sprint - Test Exxecution')

	@Keyword
	def projedit(){
		WebUI.click(projpageclick)
		WebUI.click(chooseprojdrop)
		WebUI.setText(droptextbox,"Demo project")
		WebUI.sendKeys(droptextbox, Keys.chord(Keys.ENTER))
		WebUI.click(searchbuttonclick)
		WebUI.click(projactionicon)
		WebUI.click(projactionedit)
		WebUI.setText(enterprojname,"Demo project")
		WebUI.click(clickenddate)
		WebUI.click(dateedit)
		WebUI.click(editsavebutton)
		WebUI.click(projpageclick)
	}

	@Keyword
	def projdelete(){
		WebUI.click(projpageclick)
		WebUI.click(chooseprojdrop)
		WebUI.setText(droptextbox,"Demo project")
		WebUI.sendKeys(droptextbox, Keys.chord(Keys.ENTER))
		WebUI.click(searchbuttonclick)
		WebUI.click(projactionicon)
		WebUI.click(projactiondelete)
		WebUI.click(projdeletconfir)
		WebUI.click(projdeletok)
		WebUI.click(projpageclick)
	}

	@Keyword
	def SprintEdit(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprint_options)
		WebUI.click(Sprint_Edit)
		WebUI.click(StatusClick)
		WebUI.scrollToElement(StatusChange, 30)
		WebUI.click(StatusChange)
		WebUI.click(SprintEdit_Save)
		WebUI.click(projpageclick)
	}

	@Keyword
	def SprintDelete(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprint_options)
		WebUI.click(Sprint_Delete)
		WebUI.click(projdeletconfir)
		WebUI.click(projdeletok)
		WebUI.click(projpageclick)
	}

	@Keyword
	def SprintView(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprint_options)
		WebUI.click(Sprint_View)
	}

	@Keyword
	def SprintTestExecution(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprint_options)
		WebUI.click(Sprint_TestExecution)
	}
}
