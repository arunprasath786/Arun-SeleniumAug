package projectspage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class ButtonVerify {

	private TestObject projpageclick = findTestObject('Object Repository/projects page/project - page - click')
	private TestObject demoprojclick = findTestObject('Object Repository/projects page/demo project click')
	private TestObject projFilter = findTestObject('Object Repository/projects page/Buttons/projHome - filter')
	private TestObject backlogFilt = findTestObject('Object Repository/projects page/Buttons/Proj baklog - filter')
	//Sprint
	private TestObject SprintFilter = findTestObject('Object Repository/projects page/Buttons/SprintPage - Filter')
	private TestObject sprint_FilDrop = findTestObject('Object Repository/projects page/Buttons/Sprint - dropdown filter')
	private TestObject Fil_ByResource = findTestObject('Object Repository/projects page/Buttons/Sprint - dropdown filter - By Resource')
	private TestObject navreleasepage = findTestObject('Object Repository/projects page/Add release/nav release page')
	private TestObject demoreleaseclick = findTestObject('Object Repository/projects page/Add release/demo release click')
	private TestObject Sprintclick = findTestObject('Object Repository/Add Workitem page/Sprint click')
	//filter options
	private TestObject Search_workitem = findTestObject('Object Repository/projects page/Sprint - Filter options/Search workitem - input')
	private TestObject Search_workitemClick = findTestObject('Object Repository/projects page/Sprint - Filter options/Search workitem - click')
	private TestObject Choose_AssignedTo = findTestObject('Object Repository/projects page/Sprint - Filter options/Choose Assigned To')
	private TestObject AssignedTo = findTestObject('Object Repository/projects page/Sprint - Filter options/Assigned - gopinath')
	private TestObject Choose_Type = findTestObject('Object Repository/projects page/Sprint - Filter options/Choose Type')
	private TestObject Type_Bug = findTestObject('Object Repository/projects page/Sprint - Filter options/Type - Bug')
	private TestObject Type_Task = findTestObject('Object Repository/projects page/Sprint - Filter options/Type - Task')
	private TestObject Choose_status = findTestObject('Object Repository/projects page/Sprint - Filter options/Choose status')
	private TestObject Status_New = findTestObject('Object Repository/projects page/Sprint - Filter options/Status - New')
	private TestObject Search_Button = findTestObject('Object Repository/projects page/Sprint - Filter options/Search button')
	private TestObject Filter_Reset = findTestObject('Object Repository/projects page/Sprint - Filter options/Filter Reset')
	private TestObject Export_excel = findTestObject('Object Repository/projects page/Sprint - Filter options/Export excel')
	private TestObject Filter_close = findTestObject('Object Repository/projects page/Sprint - Filter options/Filter - close')
    //Proj grid sort image
	private TestObject priority_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/Priority sort')
	private TestObject projEnd_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/Proj end date sort')
	private TestObject projStart_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/Proj start date sort')
	private TestObject Status_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/Proj status sort')
	private TestObject Type_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/Proj type sort')
	private TestObject projName_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/project name sort')
	private TestObject ReleName_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/Release name sort')
	private TestObject Rele_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/Release sort')
	private TestObject Userstory_sort = findTestObject('Object Repository/projects page/Verify Elements/project grid sort image/User story sort')
	
	@Keyword
	def filterButton(){
		WebUI.click(projpageclick)
		WebUI.click(projFilter)
		WebUI.click(projFilter)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(backlogFilt)
		WebUI.click(backlogFilt)
		WebUI.click(projpageclick)
	}

	@Keyword
	def Sprint_filterButton(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprintclick)
		WebUI.click(SprintFilter)
		WebUI.click(sprint_FilDrop)
		WebUI.click(Fil_ByResource)
		WebUI.click(projpageclick)
	}
	@Keyword
	def Sprint_filterOptions(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprintclick)
		WebUI.click(SprintFilter)
		WebUI.setText(Search_workitem,"Demo")
		WebUI.click(Search_workitemClick)
		WebUI.click(Search_Button)
		WebUI.click(Filter_Reset)
		WebUI.click(Choose_AssignedTo)
		WebUI.scrollToElement(AssignedTo, 30)
		WebUI.click(AssignedTo)
		WebUI.click(Search_Button)
		WebUI.click(Filter_Reset)
		WebUI.click(Choose_Type)
		WebUI.click(Type_Bug)
		WebUI.click(Type_Task)
		WebUI.click(Search_Button)
		WebUI.click(Filter_Reset)
		WebUI.click(Choose_status)
		WebUI.scrollToElement(Status_New, 30)
		WebUI.click(Status_New)
		WebUI.click(Search_Button)
		WebUI.click(Filter_Reset)
		WebUI.click(Export_excel)
		WebUI.click(Filter_close)
}
	@Keyword
	def ProjGrid_Sort(){
		WebUI.click(projpageclick)
		WebUI.click(priority_sort)
		WebUI.click(priority_sort)
		WebUI.click(projEnd_sort)
		WebUI.click(projEnd_sort)
		WebUI.click(projStart_sort)
		WebUI.click(projStart_sort)
		WebUI.click(Status_sort)
		WebUI.click(Status_sort)
		WebUI.click(Type_sort)
		WebUI.click(Type_sort)
		WebUI.click(projName_sort)
		WebUI.click(projName_sort)
		WebUI.click(ReleName_sort)
		WebUI.click(ReleName_sort)
		WebUI.click(Rele_sort)
		WebUI.click(Rele_sort)
		WebUI.click(Userstory_sort)
		WebUI.click(Userstory_sort)	
	}
}