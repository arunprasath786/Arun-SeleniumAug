package projectspage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class VerifyElements {

	private TestObject Sprint_UserStorykpi = findTestObject('projects page/Verify Elements/Sprint- user story kpi')
	private TestObject Sprint_Taskkpi = findTestObject('projects page/Verify Elements/Sprint - Task kpi')
	private TestObject Sprint_Bugkpi = findTestObject('projects page/Verify Elements/Sprint - Bug kpi')
	private TestObject demoprojclick = findTestObject('Object Repository/projects page/demo project click')
	private TestObject navreleasepage = findTestObject('Object Repository/projects page/Add release/nav release page')
	private TestObject demoreleaseclick = findTestObject('Object Repository/projects page/Add release/demo release click')
	private TestObject projpageclick = findTestObject('Object Repository/projects page/project - page - click')
	private TestObject Sprintclick = findTestObject('Object Repository/Add Workitem page/Sprint click')
    //proj Home
	private TestObject ActiveProj = findTestObject('Object Repository/projects page/Verify Elements/project page/Active - proj kpi')
	private TestObject TotalProj = findTestObject('Object Repository/projects page/Verify Elements/project page/Total - proj kpi')
	private TestObject UpcomingProj = findTestObject('Object Repository/projects page/Verify Elements/project page/Upcoming - proj')
	private TestObject OverdueProj = findTestObject('Object Repository/projects page/Verify Elements/project page/Overdue - proj')
	private TestObject HoldProj = findTestObject('Object Repository/projects page/Verify Elements/project page/Hold untouched - proj')
	//proj grid
	private TestObject Actions = findTestObject('Object Repository/projects page/Verify Elements/project grid/Actions')
	private TestObject Priority = findTestObject('Object Repository/projects page/Verify Elements/project grid/Priority')
	private TestObject ProjEnd = findTestObject('Object Repository/projects page/Verify Elements/project grid/Proj end date')
	private TestObject ProjStart = findTestObject('Object Repository/projects page/Verify Elements/project grid/Proj start date')
	private TestObject ProjStatus = findTestObject('Object Repository/projects page/Verify Elements/project grid/Proj status')
	private TestObject ProjType = findTestObject('Object Repository/projects page/Verify Elements/project grid/Proj Type')
	private TestObject ProjName = findTestObject('Object Repository/projects page/Verify Elements/project grid/project name')
	private TestObject ReleCount = findTestObject('Object Repository/projects page/Verify Elements/project grid/Release count')
	private TestObject ReleName = findTestObject('Object Repository/projects page/Verify Elements/project grid/Release Name')
	private TestObject Userstory = findTestObject('Object Repository/projects page/Verify Elements/project grid/User story')
	
	@Keyword
	def verifyelement_SprintPage(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(Sprintclick)

		if(WebUI.verifyElementPresent(Sprint_UserStorykpi, 5)) {
			System.out.println("User story Element is present");
			System.out.println(WebUI.getText(Sprint_UserStorykpi));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(Sprint_Taskkpi, 5)) {
			System.out.println("Task Element is present");
			System.out.println(WebUI.getText(Sprint_Taskkpi));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(Sprint_Bugkpi, 5)) {
			System.out.println("Bugs Element is present");
			System.out.println(WebUI.getText(Sprint_Bugkpi));
		}
		else {
			System.out.println("Element not present");
		}
	}
	
	@Keyword
	def verifyelement_ProjHome(){
		WebUI.click(projpageclick)
		if(WebUI.verifyElementPresent(ActiveProj, 5)) {
			System.out.println("Active projects Element is present");
			System.out.println(WebUI.getText(ActiveProj));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(TotalProj, 5)) {
			System.out.println("Total projects Element is present");
			System.out.println(WebUI.getText(TotalProj));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(UpcomingProj, 5)) {
			System.out.println("Upcoming projects Element is present");
			System.out.println(WebUI.getText(UpcomingProj));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(OverdueProj, 5)) {
			System.out.println("Overdue projects Element is present");
			System.out.println(WebUI.getText(OverdueProj));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(HoldProj, 5)) {
			System.out.println("Hold/Untouched projects Element is present");
			System.out.println(WebUI.getText(HoldProj));
		}
		else {
			System.out.println("Element not present");
		}
	}
	
	@Keyword
	def verifyelement_ProjGrid(){
		WebUI.click(projpageclick)
		if(WebUI.verifyElementPresent(Actions, 5)) {
			System.out.println("Actions Element is present");
			System.out.println(WebUI.getText(Actions));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(Priority, 5)) {
			System.out.println("Priority Element is present");
			System.out.println(WebUI.getText(Priority));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(ProjEnd, 5)) {
			System.out.println("Project End Date Element is present");
			System.out.println(WebUI.getText(ProjEnd));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(ProjStart, 5)) {
			System.out.println("Project start Date Element is present");
			System.out.println(WebUI.getText(ProjStart));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(ProjStatus, 5)) {
			System.out.println("Status Element is present");
			System.out.println(WebUI.getText(ProjStatus));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(ProjType, 5)) {
			System.out.println("Project Type Element is present");
			System.out.println(WebUI.getText(ProjType));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(ProjName, 5)) {
			System.out.println("Project Name Element is present");
			System.out.println(WebUI.getText(ProjName));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(ReleCount, 5)) {
			System.out.println("Release count Element is present");
			System.out.println(WebUI.getText(ReleCount));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(ReleName, 5)) {
			System.out.println("Release Name Element is present");
			System.out.println(WebUI.getText(ReleName));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(Userstory, 5)) {
			System.out.println("Userstory Element is present");
			System.out.println(WebUI.getText(Userstory));
		}
		else {
			System.out.println("Element not present");
		}
	}
}
