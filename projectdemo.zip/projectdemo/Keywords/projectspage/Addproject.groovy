package projectspage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import org.openqa.selenium.Keys as Keys
import internal.GlobalVariable

public class Addproject {

	private TestObject addprojbutton = findTestObject('Object Repository/projects page/Add project/add proj button click')
	private TestObject enterprojname = findTestObject('Object Repository/projects page/Add project/enter proj name')
	private TestObject choosestatus = findTestObject('Object Repository/projects page/Add release/choose status')
	private TestObject enddate = findTestObject('Object Repository/projects page/Add project/proj end date')
	private TestObject savebutton = findTestObject('Object Repository/projects page/Add project/add proj save button')
	private TestObject projpageclick = findTestObject('Object Repository/projects page/project - page - click')
	private TestObject yettostart = findTestObject('Object Repository/projects page/Add release/status - yet to start')
	private TestObject chooseprojdrop = findTestObject('Object Repository/projects page/choose project drop')
	private TestObject droptextbox = findTestObject('Object Repository/projects page/subtype search textbox')
	private TestObject searchbuttonclick = findTestObject('Object Repository/projects page/search button click')
	private TestObject demoprojclick = findTestObject('Object Repository/projects page/demo project click')
	private TestObject plussymbol = findTestObject('Object Repository/proj-reg-sprint1/plus symbol -add workitem')
	private TestObject addrelease = findTestObject('Object Repository/projects page/Add release/add release click')
	private TestObject enterreleasname = findTestObject('Object Repository/projects page/Add release/enter release name')
	private TestObject navreleasepage = findTestObject('Object Repository/projects page/Add release/nav release page')
	private TestObject demoreleaseclick = findTestObject('Object Repository/projects page/Add release/demo release click')
	private TestObject addsprintclick = findTestObject('Object Repository/projects page/Add sprint/add sprint click')
	private TestObject entersprintname = findTestObject('Object Repository/projects page/Add sprint/enter sprint name')
	//milestone
	private TestObject AddMilestone = findTestObject('Object Repository/projects page/Add milestone/Add milstone click')
	private TestObject enterMilestonename = findTestObject('Object Repository/projects page/Add milestone/Enter milestone name')
	private TestObject StatusName = findTestObject('Object Repository/projects page/Add milestone/choose status name')
	private TestObject Status_yetToStart = findTestObject('Object Repository/projects page/Add milestone/status - yet to start')
	private TestObject MilestoneOn = findTestObject('Object Repository/projects page/Add milestone/Enter milestone on')
	private TestObject Associate_slide = findTestObject('Object Repository/projects page/Add milestone/Right-Slide -Milestone-Associate')
	private TestObject Associate_AddMilestone = findTestObject('Object Repository/projects page/Add milestone/Right-Slide-Add Milestone')
	private TestObject AddExtra_Hours = findTestObject('Object Repository/projects page/Add milestone/Add Extra hours')
	private TestObject ExtraHours_summary = findTestObject('Object Repository/projects page/Add milestone/ExtraHours - summary')
	private TestObject Enter_ExtraHours = findTestObject('Object Repository/projects page/Add milestone/Enter Extra hours')
	private TestObject ExtraHours_AddButton = findTestObject('Object Repository/projects page/Add milestone/ExtraHours - Add button')
	private TestObject ExtraHours_CloseButton = findTestObject('Object Repository/projects page/Add milestone/ExtraHours - close button')
	//meeting
	private TestObject Details = findTestObject('Object Repository/projects page/Add meeting/Sidebar-detail-meeting')
	private TestObject Addmeeting = findTestObject('Object Repository/projects page/Add meeting/Sidebar-detail-Add meeting')
	private TestObject meetingName = findTestObject('Object Repository/projects page/Add meeting/Enter meeting name')
	private TestObject meetingOn = findTestObject('Object Repository/projects page/Add meeting/Meeting on')
	private TestObject chooseStartTime = findTestObject('Object Repository/projects page/Add meeting/choosse start time')
	private TestObject StartTimeHour = findTestObject('Object Repository/projects page/Add meeting/Start time - Hour')
	private TestObject TimeMinute = findTestObject('Object Repository/projects page/Add meeting/Time - Minute')
	private TestObject TimeOk = findTestObject('Object Repository/projects page/Add meeting/Time - okay button')
	private TestObject EndTime = findTestObject('Object Repository/projects page/Add meeting/Choose end time')
	private TestObject EndtimeHour = findTestObject('Object Repository/projects page/Add meeting/End time - Hour')
	private TestObject Requiredppl = findTestObject('Object Repository/projects page/Add meeting/Required people')
	private TestObject pplRanjitha = findTestObject('Object Repository/projects page/Add meeting/Required people- ranjitha')
	private TestObject pplsravani = findTestObject('Object Repository/projects page/Add meeting/Required people- sravani')
	private TestObject SaveMeeting = findTestObject('Object Repository/projects page/Add meeting/Save_Meeting')
	//Delay
	private TestObject Add_Delay = findTestObject('Object Repository/projects page/Add Delay/Add delay click')
	private TestObject ChooseCategory = findTestObject('Object Repository/projects page/Add Delay/Choose category')
	private TestObject cat_Dependency = findTestObject('Object Repository/projects page/Add Delay/Category - Dependency')
	private TestObject EnterTitle = findTestObject('Object Repository/projects page/Add Delay/Enter title')
	private TestObject DelaySave = findTestObject('Object Repository/projects page/Add Delay/Delay save button')
	//observation
	private TestObject Add_observat = findTestObject('Object Repository/projects page/Add observation/Add observation')
	private TestObject EnterObvTitle = findTestObject('Object Repository/projects page/Add observation/Enter title')
	private TestObject Obvsave = findTestObject('Object Repository/projects page/Add observation/Observation save button')
	//Risk
	private TestObject Add_Risk = findTestObject('Object Repository/projects page/Add Risk/Add risk')
	private TestObject RiskTitle = findTestObject('Object Repository/projects page/Add Risk/Risk title')
	private TestObject RiskSave = findTestObject('Object Repository/projects page/Add Risk/Risk save button')
	//Decision
	private TestObject Add_Decision = findTestObject('Object Repository/projects page/Add Decision/Add Decision')
	private TestObject DecisionTitle = findTestObject('Object Repository/projects page/Add Decision/Decision Title')
	private TestObject DecisionSave = findTestObject('Object Repository/projects page/Add Decision/Decision save button')
	//Back button
	private TestObject BackButton = findTestObject('Object Repository/projects page/Buttons/Back')

	@Keyword
	def addproj(){
		WebUI.click(projpageclick)
		WebUI.click(addprojbutton)
		WebUI.setText(enterprojname,"Demo project")
		WebUI.click(choosestatus)
		WebUI.click(yettostart)
		WebUI.clearText(enddate)
		WebUI.setText(enddate,"01/20/2020")
		WebUI.click(savebutton)
		WebUI.click(projpageclick)
	}

	@Keyword
	def addrelease(){
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(plussymbol)
		WebUI.click(addrelease)
		WebUI.setText(enterreleasname,"Demo project-Release1")
		WebUI.click(choosestatus)
		WebUI.click(yettostart)
		WebUI.clearText(enddate)
		WebUI.setText(enddate,"01/20/2020")
		WebUI.click(savebutton)
		WebUI.click(projpageclick)
	}

	@Keyword
	def addsprint(){
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(navreleasepage)
		WebUI.click(demoreleaseclick)
		WebUI.click(plussymbol)
		WebUI.click(addsprintclick)
		WebUI.setText(entersprintname,"Sprint1")
		WebUI.click(choosestatus)
		WebUI.click(yettostart)
		WebUI.clearText(enddate)
		WebUI.setText(enddate,"01/20/2020")
		WebUI.click(savebutton)
		WebUI.click(projpageclick)
	}
	@Keyword
	def addMilestone(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(plussymbol)
		WebUI.click(AddMilestone)
		WebUI.setText(enterMilestonename,"Test_Milestone")
		WebUI.click(StatusName)
		WebUI.click(Status_yetToStart)
		WebUI.clearText(MilestoneOn)
		WebUI.setText(MilestoneOn,"01/23/2020")
		WebUI.click(savebutton)
		WebUI.click(projpageclick)
	}
	@Keyword
	def Milestone_Extrahours(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(Associate_slide)
		WebUI.click(AddExtra_Hours)
		WebUI.setText(ExtraHours_summary,"Milestone - Extra Hours")
		WebUI.setText(Enter_ExtraHours,"3")
		WebUI.click(ExtraHours_AddButton)
		WebUI.click(ExtraHours_CloseButton)
	}
	@Keyword
	def addMilestone_AssociaSlide(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(Associate_slide)
		WebUI.click(Associate_AddMilestone)
		WebUI.setText(enterMilestonename,"Test_Milestone")
		WebUI.click(StatusName)
		WebUI.click(Status_yetToStart)
		WebUI.clearText(MilestoneOn)
		WebUI.setText(MilestoneOn,"01/23/2020")
		WebUI.click(savebutton)
		WebUI.click(projpageclick)
	}

	@Keyword
	def addMeeting(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(Details)
		WebUI.click(Addmeeting)
		WebUI.setText(meetingName,"Test_Meet")
		WebUI.click(chooseStartTime)
		WebUI.click(StartTimeHour)
		WebUI.click(TimeMinute)
		WebUI.click(TimeOk)
		WebUI.click(EndTime)
		WebUI.click(EndtimeHour)
		WebUI.click(TimeMinute)
		WebUI.click(TimeOk)
		WebUI.click(Requiredppl)
		WebUI.scrollToElement(pplRanjitha, 30)
		WebUI.click(pplRanjitha)
		WebUI.scrollToElement(pplsravani, 30)
		WebUI.click(pplsravani)
		WebUI.clearText(meetingOn)
		WebUI.setText(meetingOn,"01/23/2020")
		WebUI.click(SaveMeeting)
		WebUI.click(projpageclick)
	}
	@Keyword
	def addDelay(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(plussymbol)
		WebUI.click(Add_Delay)
		WebUI.setText(EnterTitle,"Delay-Title")
		WebUI.click(ChooseCategory)
		WebUI.click(cat_Dependency)
		WebUI.click(DelaySave)
		WebUI.click(projpageclick)
	}
	@Keyword
	def addObservation(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(plussymbol)
		WebUI.click(Add_observat)
		WebUI.setText(EnterObvTitle,"Observation-Title")
		WebUI.click(Obvsave)
		WebUI.click(projpageclick)
	}
	@Keyword
	def addRisk(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(plussymbol)
		WebUI.click(Add_Risk)
		WebUI.setText(RiskTitle,"Risk-Title")
		WebUI.click(RiskSave)
		WebUI.click(projpageclick)
	}
	@Keyword
	def addDecision(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(plussymbol)
		WebUI.click(Add_Decision)
		WebUI.setText(DecisionTitle,"Decision-Title")
		WebUI.click(DecisionSave)
		WebUI.click(projpageclick)
	}
	@Keyword
	def Back_button(){
		WebUI.click(projpageclick)
		WebUI.scrollToElement(demoprojclick, 30)
		WebUI.click(demoprojclick)
		WebUI.click(BackButton)
	}
}
