package homepage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class ProjectListing {

	private TestObject project1 = findTestObject('Object Repository/Homepage/Home project listing/project1')
	private TestObject proj1getText = findTestObject('Object Repository/Homepage/Home project listing/project1 - getText')
	private TestObject project2 = findTestObject('Object Repository/Homepage/Home project listing/project2')
	private TestObject proj2getText = findTestObject('Object Repository/Homepage/Home project listing/project2 - getText')
	private TestObject project3 = findTestObject('Object Repository/Homepage/Home project listing/project3')
	private TestObject proj3getText = findTestObject('Object Repository/Homepage/Home project listing/project3 - getText')
	private TestObject HomeClick = findTestObject('Object Repository/Homepage/Home click')

	@Keyword
	def projListingcheck(){

		if(WebUI.verifyElementPresent(project1, 5)) {
			System.out.println("project1 is listed");
			System.out.println(WebUI.getText(proj1getText));
		}
		else {
			System.out.println("project not present");
		}
		if(WebUI.verifyElementPresent(project2, 5)) {
			System.out.println("project2 is listed");
			System.out.println(WebUI.getText(proj2getText));
		}
		else {
			System.out.println("project not present");
		}
		if(WebUI.verifyElementPresent(project3, 5)) {
			System.out.println("project3 is listed");
			System.out.println(WebUI.getText(proj3getText));
		}
		else {
			System.out.println("project not present");
		}
	}

	@Keyword
	def proj_click(){
		WebUI.click(project1)
		WebUI.click(HomeClick)
		WebUI.click(project2)
		WebUI.click(HomeClick)
		WebUI.click(project3)
		WebUI.click(HomeClick)
	}
}
