package homepage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class Regressiontesting {

	private TestObject clickprojectreg = findTestObject('Object Repository/Homepage/Project-regression testing')
	private TestObject sprint1click = findTestObject('Object Repository/proj-reg-sprint1/Regression - sprint1')
	private TestObject newbugclick = findTestObject('Object Repository/proj-reg-sprint1/new bug')
	private TestObject descenter = findTestObject('Object Repository/proj-reg-sprint1/new bug - description')
	private TestObject update = findTestObject('Object Repository/proj-reg-sprint1/Bug -update button')
	private TestObject projpageclick = findTestObject('Object Repository/projects page/project - page - click')

	@Keyword
	def updateregressionbug(){
		clickregression()
		clickregressionsprint1()
		clicknewbug()
		enterdescription()
		updatebuttonclick()
	}

	@Keyword
	def clickregression(){
		WebUI.click(clickprojectreg)
	}

	@Keyword
	def clickregressionsprint1(){
		WebUI.click(sprint1click)
	}

	@Keyword
	def clicknewbug(){
		WebUI.click(newbugclick)
	}

	@Keyword
	def enterdescription(){
		WebUI.setText(descenter,"Description of the bug")
	}

	@Keyword
	def updatebuttonclick(){
		WebUI.click(update)
	}

	@Keyword
	def projclick(){
		WebUI.click(projpageclick)
	}
}
