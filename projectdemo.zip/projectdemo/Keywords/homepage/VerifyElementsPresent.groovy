package homepage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class VerifyElementsPresent {


	private TestObject Activeprojkpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/Active proj - kpi')
	private TestObject verifyactiveproj = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/Active projs')
	private TestObject verifyTask = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/Task')
	private TestObject Taskkpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/Task - kpi')
	private TestObject verifyUserStory = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/User story')
	private TestObject Userstorykpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/User story - kpi')
	private TestObject verifyBugs = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/Bugs')
	private TestObject Bugskpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/Bugs - kpi')
	private TestObject verifyRisk = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/Risk')
	private TestObject Riskkpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Top header kpi/Risk - kpi')

	private TestObject projects = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/projects')
	private TestObject projectskpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/projects - kpi')
	private TestObject planned = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/planned vs actual')
	private TestObject plannedkpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/planned vs actual kpi')
	private TestObject overdue = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/overdue')
	private TestObject overduekpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/overdue - kpi')
	private TestObject New = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/New')
	private TestObject Newkpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/New - kpi')
	private TestObject Unalloated = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/Unallocated')
	private TestObject Unallocatedkpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/Unallocated - kpi')
	private TestObject NA = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/NA')
	private TestObject NAkpi = findTestObject('Object Repository/Homepage/VerifyElements/Home - Left side bar kpi/NA - kpi')

	@Keyword
	def verifyelement_HomeTop(){
		if(WebUI.verifyElementPresent(verifyactiveproj, 5)) {
			System.out.println("Active projects Element is present");
			System.out.println(WebUI.getText(Activeprojkpi));
		}
		else {
			System.out.println("Element not present");
		}

		if(WebUI.verifyElementPresent(verifyTask, 5)) {
			System.out.println("Task Element is present");
			System.out.println(WebUI.getText(Taskkpi));
		}
		else {
			System.out.println("Element not present");
		}

		if(WebUI.verifyElementPresent(verifyUserStory, 5)) {
			System.out.println("User story Element is present");
			System.out.println(WebUI.getText(Userstorykpi));
		}
		else {
			System.out.println("Element not present");
		}

		if(WebUI.verifyElementPresent(verifyBugs, 5)) {
			System.out.println("Bugs Element is present");
			System.out.println(WebUI.getText(Bugskpi));
		}
		else {
			System.out.println("Element not present");
		}

		if(WebUI.verifyElementPresent(verifyRisk, 5)) {
			System.out.println("Risk Element is present");
			System.out.println(WebUI.getText(Riskkpi));
		}
		else {
			System.out.println("Element not present");
		}
	}

	@Keyword
	def verifyelement_HomeSideBar(){
		if(WebUI.verifyElementPresent(projects, 5)) {
			System.out.println("projects Element is present");
			System.out.println(WebUI.getText(projectskpi));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(planned, 5)) {
			System.out.println("planned Element is present");
			System.out.println(WebUI.getText(plannedkpi));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(overdue, 5)) {
			System.out.println("overdue Element is present");
			System.out.println(WebUI.getText(overduekpi));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(New, 5)) {
			System.out.println("New Element is present");
			System.out.println(WebUI.getText(Newkpi));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(Unalloated, 5)) {
			System.out.println("Unalloated Element is present");
			System.out.println(WebUI.getText(Unallocatedkpi));
		}
		else {
			System.out.println("Element not present");
		}
		if(WebUI.verifyElementPresent(NA, 5)) {
			System.out.println("NA Element is present");
			System.out.println(WebUI.getText(NAkpi));
		}
		else {
			System.out.println("Element not present");
		}
	}
}

