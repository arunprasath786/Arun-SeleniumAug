package homepage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class ReleaseDropdown {
	private TestObject ReleaseDrop = findTestObject('Object Repository/Homepage/Release dropdown/Release drop click')
	private TestObject Anydate = findTestObject('Object Repository/Homepage/Release dropdown/Any date')
	private TestObject yesterday = findTestObject('Object Repository/Homepage/Release dropdown/Yesterday')
	private TestObject today = findTestObject('Object Repository/Homepage/Release dropdown/Today')
	private TestObject Lastweek = findTestObject('Object Repository/Homepage/Release dropdown/Last week')
	private TestObject Thisweek = findTestObject('Object Repository/Homepage/Release dropdown/This week')
	private TestObject Lastmonth = findTestObject('Object Repository/Homepage/Release dropdown/Last month')
	private TestObject Nextmonth = findTestObject('Object Repository/Homepage/Release dropdown/Next month')
	private TestObject Thismonth = findTestObject('Object Repository/Homepage/Release dropdown/This month')
	private TestObject Lastyear = findTestObject('Object Repository/Homepage/Release dropdown/Last year')
	private TestObject Thisyear = findTestObject('Object Repository/Homepage/Release dropdown/This year')
	private TestObject Custom = findTestObject('Object Repository/Homepage/Release dropdown/custom range')
	private TestObject Customstart = findTestObject('Object Repository/Homepage/Release dropdown/custom start date')
	private TestObject Customend = findTestObject('Object Repository/Homepage/Release dropdown/custom end date')
	private TestObject Customapplybut = findTestObject('Object Repository/Homepage/Release dropdown/custom apply button')
	private TestObject HomeClick = findTestObject('Object Repository/Homepage/Home click')
	@Keyword
	def Releasedropdown(){
		
		WebUI.click(ReleaseDrop)
		WebUI.click(Anydate)
		WebUI.click(ReleaseDrop)
		WebUI.click(yesterday)
		WebUI.click(ReleaseDrop)
		WebUI.click(today)
		WebUI.click(ReleaseDrop)
		WebUI.click(Lastweek)
		WebUI.click(ReleaseDrop)
		WebUI.click(Thisweek)
		WebUI.click(ReleaseDrop)
		WebUI.click(Lastmonth)
		WebUI.click(ReleaseDrop)
		WebUI.click(Nextmonth)
		WebUI.click(ReleaseDrop)
		WebUI.click(Thismonth)
		WebUI.click(ReleaseDrop)
		WebUI.click(Lastyear)
		WebUI.click(ReleaseDrop)
		WebUI.click(Thisyear)
		WebUI.click(ReleaseDrop)
		WebUI.click(Custom)
		WebUI.click(Customstart)
		WebUI.click(Customend)
		WebUI.click(Customapplybut)
	}
	
}
