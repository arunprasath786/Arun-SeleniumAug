
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String


def static "loginpage.logintopp.loginfun"(
    	String username	
     , 	String password	) {
    (new loginpage.logintopp()).loginfun(
        	username
         , 	password)
}

def static "loginpage.logintopp.enterusername"(
    	String userName	) {
    (new loginpage.logintopp()).enterusername(
        	userName)
}

def static "loginpage.logintopp.enterpassword"(
    	String password	) {
    (new loginpage.logintopp()).enterpassword(
        	password)
}

def static "loginpage.logintopp.clickloginbutton"() {
    (new loginpage.logintopp()).clickloginbutton()
}

def static "addworkitem.newbug.newbugsubmit"() {
    (new addworkitem.newbug()).newbugsubmit()
}

def static "addworkitem.newbug.addworkitemplussymb"() {
    (new addworkitem.newbug()).addworkitemplussymb()
}

def static "addworkitem.newbug.newtasksubmit"() {
    (new addworkitem.newbug()).newtasksubmit()
}

def static "addworkitem.newbug.Sprint_newtasksubmit"() {
    (new addworkitem.newbug()).Sprint_newtasksubmit()
}

def static "addworkitem.newbug.Sprint_newBugsubmit"() {
    (new addworkitem.newbug()).Sprint_newBugsubmit()
}

def static "homepage.ProjectListing.projListingcheck"() {
    (new homepage.ProjectListing()).projListingcheck()
}

def static "homepage.ProjectListing.proj_click"() {
    (new homepage.ProjectListing()).proj_click()
}

def static "projectspage.Addproject.addproj"() {
    (new projectspage.Addproject()).addproj()
}

def static "projectspage.Addproject.addrelease"() {
    (new projectspage.Addproject()).addrelease()
}

def static "projectspage.Addproject.addsprint"() {
    (new projectspage.Addproject()).addsprint()
}

def static "projectspage.Addproject.addMilestone"() {
    (new projectspage.Addproject()).addMilestone()
}

def static "projectspage.Addproject.Milestone_Extrahours"() {
    (new projectspage.Addproject()).Milestone_Extrahours()
}

def static "projectspage.Addproject.addMilestone_AssociaSlide"() {
    (new projectspage.Addproject()).addMilestone_AssociaSlide()
}

def static "projectspage.Addproject.addMeeting"() {
    (new projectspage.Addproject()).addMeeting()
}

def static "projectspage.Addproject.addDelay"() {
    (new projectspage.Addproject()).addDelay()
}

def static "projectspage.Addproject.addObservation"() {
    (new projectspage.Addproject()).addObservation()
}

def static "projectspage.Addproject.addRisk"() {
    (new projectspage.Addproject()).addRisk()
}

def static "projectspage.Addproject.addDecision"() {
    (new projectspage.Addproject()).addDecision()
}

def static "projectspage.Addproject.Back_button"() {
    (new projectspage.Addproject()).Back_button()
}

def static "homepage.ReleaseDropdown.Releasedropdown"() {
    (new homepage.ReleaseDropdown()).Releasedropdown()
}

def static "projectspage.VerifyElements.verifyelement_SprintPage"() {
    (new projectspage.VerifyElements()).verifyelement_SprintPage()
}

def static "projectspage.VerifyElements.verifyelement_ProjHome"() {
    (new projectspage.VerifyElements()).verifyelement_ProjHome()
}

def static "projectspage.VerifyElements.verifyelement_ProjGrid"() {
    (new projectspage.VerifyElements()).verifyelement_ProjGrid()
}

def static "browser.browserlaunch.launchbrowser"() {
    (new browser.browserlaunch()).launchbrowser()
}

def static "homepage.VerifyElementsPresent.verifyelement_HomeTop"() {
    (new homepage.VerifyElementsPresent()).verifyelement_HomeTop()
}

def static "homepage.VerifyElementsPresent.verifyelement_HomeSideBar"() {
    (new homepage.VerifyElementsPresent()).verifyelement_HomeSideBar()
}

def static "homepage.Regressiontesting.updateregressionbug"() {
    (new homepage.Regressiontesting()).updateregressionbug()
}

def static "homepage.Regressiontesting.clickregression"() {
    (new homepage.Regressiontesting()).clickregression()
}

def static "homepage.Regressiontesting.clickregressionsprint1"() {
    (new homepage.Regressiontesting()).clickregressionsprint1()
}

def static "homepage.Regressiontesting.clicknewbug"() {
    (new homepage.Regressiontesting()).clicknewbug()
}

def static "homepage.Regressiontesting.enterdescription"() {
    (new homepage.Regressiontesting()).enterdescription()
}

def static "homepage.Regressiontesting.updatebuttonclick"() {
    (new homepage.Regressiontesting()).updatebuttonclick()
}

def static "homepage.Regressiontesting.projclick"() {
    (new homepage.Regressiontesting()).projclick()
}

def static "projectspage.ButtonVerify.filterButton"() {
    (new projectspage.ButtonVerify()).filterButton()
}

def static "projectspage.ButtonVerify.Sprint_filterButton"() {
    (new projectspage.ButtonVerify()).Sprint_filterButton()
}

def static "projectspage.ButtonVerify.Sprint_filterOptions"() {
    (new projectspage.ButtonVerify()).Sprint_filterOptions()
}

def static "projectspage.ButtonVerify.ProjGrid_Sort"() {
    (new projectspage.ButtonVerify()).ProjGrid_Sort()
}

def static "projectspage.Editprojrelspr.projedit"() {
    (new projectspage.Editprojrelspr()).projedit()
}

def static "projectspage.Editprojrelspr.projdelete"() {
    (new projectspage.Editprojrelspr()).projdelete()
}

def static "projectspage.Editprojrelspr.SprintEdit"() {
    (new projectspage.Editprojrelspr()).SprintEdit()
}

def static "projectspage.Editprojrelspr.SprintDelete"() {
    (new projectspage.Editprojrelspr()).SprintDelete()
}

def static "projectspage.Editprojrelspr.SprintView"() {
    (new projectspage.Editprojrelspr()).SprintView()
}

def static "projectspage.Editprojrelspr.SprintTestExecution"() {
    (new projectspage.Editprojrelspr()).SprintTestExecution()
}
