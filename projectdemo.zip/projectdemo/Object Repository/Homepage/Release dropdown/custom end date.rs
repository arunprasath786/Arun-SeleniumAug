<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>custom end date</name>
   <tag></tag>
   <elementGuidId>1bf9fd6e-b1b7-489a-8644-cbb3be58b0d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//td[text()='22'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
