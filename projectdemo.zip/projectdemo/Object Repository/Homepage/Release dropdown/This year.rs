<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>This year</name>
   <tag></tag>
   <elementGuidId>2e277c5f-ca1d-4f88-926a-c3c9446ef55c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[text()='This Year']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
