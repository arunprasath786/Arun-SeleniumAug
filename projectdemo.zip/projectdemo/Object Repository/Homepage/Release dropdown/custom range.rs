<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>custom range</name>
   <tag></tag>
   <elementGuidId>782a2a4a-dc27-4c6f-be72-e02a01632305</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[text()='Custom Range']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
