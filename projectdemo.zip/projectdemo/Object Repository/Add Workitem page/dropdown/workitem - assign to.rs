<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>workitem - assign to</name>
   <tag></tag>
   <elementGuidId>8766f096-49e7-4837-91aa-cb7a8efb7082</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[text()='Gopinath']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
