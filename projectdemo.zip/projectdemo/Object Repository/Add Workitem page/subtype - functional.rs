<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>subtype - functional</name>
   <tag></tag>
   <elementGuidId>fe7072b5-929d-48d4-b1f4-2dd895e4da71</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
