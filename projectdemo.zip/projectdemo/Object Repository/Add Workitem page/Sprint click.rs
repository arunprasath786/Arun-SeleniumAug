<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Sprint click</name>
   <tag></tag>
   <elementGuidId>c51e9c86-14be-408e-9220-5eb17a0c3455</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//h3[text()='Sprint1'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
