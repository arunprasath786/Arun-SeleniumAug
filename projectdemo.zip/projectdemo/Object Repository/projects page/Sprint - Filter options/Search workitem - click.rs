<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Search workitem - click</name>
   <tag></tag>
   <elementGuidId>3bd65d8e-e847-4911-9b19-383321c55ad2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h6[@title='&lt;strong>Demo&lt;/strong> bug submit']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
