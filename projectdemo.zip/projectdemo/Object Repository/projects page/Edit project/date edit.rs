<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>date edit</name>
   <tag></tag>
   <elementGuidId>cf9d10f5-bafa-44a5-9bf2-5983e11096c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[text()='25']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
