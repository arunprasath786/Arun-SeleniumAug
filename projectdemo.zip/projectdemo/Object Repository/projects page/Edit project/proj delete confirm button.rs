<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>proj delete confirm button</name>
   <tag></tag>
   <elementGuidId>070be63b-bb4a-4771-82d2-7f9f21813a34</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[text()='confirm']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
