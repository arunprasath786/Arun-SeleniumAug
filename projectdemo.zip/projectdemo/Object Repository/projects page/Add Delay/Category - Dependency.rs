<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Category - Dependency</name>
   <tag></tag>
   <elementGuidId>f9a598dc-b809-4c2c-934e-5888be449a52</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[text()='Dependency ']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
