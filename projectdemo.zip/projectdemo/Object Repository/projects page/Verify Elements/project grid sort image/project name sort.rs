<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>project name sort</name>
   <tag></tag>
   <elementGuidId>8c44b98f-d6e2-4ee9-bfd3-810422cdc52f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//img[@class='th-shorting-s1'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
