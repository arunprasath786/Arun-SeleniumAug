<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Proj type sort</name>
   <tag></tag>
   <elementGuidId>851b66f0-c197-439b-b930-1a42a8604b69</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//img[@class='th-shorting-s1'])[5]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
