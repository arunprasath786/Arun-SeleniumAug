<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Release sort</name>
   <tag></tag>
   <elementGuidId>9940f960-28dc-4001-b51e-7894c35f1e7d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//img[@class='th-shorting-s1'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
