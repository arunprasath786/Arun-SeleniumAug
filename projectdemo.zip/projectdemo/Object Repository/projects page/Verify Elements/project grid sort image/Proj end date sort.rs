<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Proj end date sort</name>
   <tag></tag>
   <elementGuidId>17e6100b-7772-4db7-aac7-23146213103b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//img[@class='th-shorting-s1'])[8]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
