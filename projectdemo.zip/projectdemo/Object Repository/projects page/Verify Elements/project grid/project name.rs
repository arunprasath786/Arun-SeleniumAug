<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>project name</name>
   <tag></tag>
   <elementGuidId>f5c07e2e-5ffe-4cf8-ac67-d5cef931bda9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//th[@data-sort='ProjectName']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
