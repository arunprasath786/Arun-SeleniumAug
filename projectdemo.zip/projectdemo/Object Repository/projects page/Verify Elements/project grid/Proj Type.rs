<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Proj Type</name>
   <tag></tag>
   <elementGuidId>e0d047e8-117f-4c35-b4cb-4572418c824d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//th[@data-sort='ProjectTypeName']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
