<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Release Name</name>
   <tag></tag>
   <elementGuidId>e89df6a8-e6d7-4b9d-914c-321677f8b1a3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//th[@data-sort='CurrentReleaseName']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
