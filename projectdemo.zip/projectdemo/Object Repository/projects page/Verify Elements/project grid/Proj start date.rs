<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Proj start date</name>
   <tag></tag>
   <elementGuidId>e392d7a8-1703-4da6-839e-056e0283f699</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//th[@data-sort='ProjectStartDate']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
