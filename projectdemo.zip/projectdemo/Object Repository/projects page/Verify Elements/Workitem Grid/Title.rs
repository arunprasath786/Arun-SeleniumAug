<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Title</name>
   <tag></tag>
   <elementGuidId>d474a740-a73f-4199-bc6f-e4c155743e04</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//th[@title ='Title'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
