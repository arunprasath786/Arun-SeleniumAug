<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Status</name>
   <tag></tag>
   <elementGuidId>51474a27-e37c-4d86-8852-7b4b8f5a87f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//th[@title ='Status'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
