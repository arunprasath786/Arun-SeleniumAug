<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Workitem Type</name>
   <tag></tag>
   <elementGuidId>76ac3563-2745-41c0-b58c-499c3df5984d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//th[@title ='Work Item Type'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
