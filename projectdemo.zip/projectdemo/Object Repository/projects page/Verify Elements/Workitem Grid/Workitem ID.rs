<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Workitem ID</name>
   <tag></tag>
   <elementGuidId>777c2dbf-59f2-4030-aead-1a34cf3e0cbf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//th[@title ='Work Item ID'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
