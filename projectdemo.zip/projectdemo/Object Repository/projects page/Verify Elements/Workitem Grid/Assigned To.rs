<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Assigned To</name>
   <tag></tag>
   <elementGuidId>ec23e3a8-b2f6-4ad7-9de0-c198f8ead039</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//th[@title ='Assigned To'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
