<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>plus symbol -add workitem</name>
   <tag></tag>
   <elementGuidId>fc43ea2f-61d1-4933-a030-e94934b10e09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//i[@class ='fa fa-plus'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
