<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Regression - sprint1</name>
   <tag></tag>
   <elementGuidId>b794c5de-4267-405d-869a-93ab933d98f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//h3[text() = 'sprint 1'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
